export interface Contacto {
    _id?: string;
    nombre: string;
    email: string;
    Latitude: string;
    Longitude: string;   
    numTel1: string;
    numTel2: string;
}