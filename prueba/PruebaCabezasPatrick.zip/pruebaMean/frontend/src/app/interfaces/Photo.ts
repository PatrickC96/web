export interface Photo {
    _id?: string;
    title: String;
    description: String;
    price:Number;
    availability:Number;
    imagePath: string;
}